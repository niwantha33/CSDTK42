/************************************************************************
;copyright		:shenzhen coolwaveasia
;filename		:lcd.c
;lcd			:TC802B-01
;control mcu	:w78e52b
;writeby		:dengyihong
;describe		:LCD control
;notice			:
;***********************************************************************/



/***********************************************************
name:		ini_lcd		
input:		none
output:		none
describe:	��ʼ��LCD	
notice:
creat date: 2008-7-25
creator:	dengyihong
************************************************************/
void ini_lcd(void)
{
    lcd_write_reg(0x38);
    lcd_write_reg(0x38);
    lcd_write_reg(0x38);
    lcd_write_reg(0x08);
    lcd_wait();
    lcd_write_reg(0x01);
    lcd_wait();
    delay_2us(50000);
    
    lcd_write_reg(0x14);
    lcd_wait();
    lcd_write_reg(0x06);
    lcd_wait();
    lcd_write_reg(0x80);
    lcd_wait();
    lcd_write_reg(0x0c);
    lcd_wait();	
}


/***********************************************************
name:		lcd_printf_string	
input:		*disp_str  ---  �����ʾ�ַ���ͷָ��
			row_len_col  ---  ��ʾ�����������ʾ�ַ���
			row_len_col:
				bit[7:6]: ��ʾ������
				bit[5:3]: ��ʾ�ַ�����
				bit[2:0]: ��ʾ�ַ�����ʼ������
output:		none
describe:	����Ļ����ʾ����ַ�		
notice:
creat date: 2008-7-25
creator:	dengyihong
************************************************************/
void lcd_printf_string(Uchar *disp_str, Uchar row_len_col)
{
    Uchar i = 0;
    Uchar len = 0;
    
    len = (row_len_col & LEN_MASK) >> 0x03;
    
    lcd_write_reg(row_len_col & ROW_COL);
    lcd_wait();
    
    for(i=0; i<=len; i++)
    {
        lcd_write_data(*disp_str++);
        lcd_wait();	
    }
}


/***********************************************************
name:		lcd_printf_char		
input:		disp_char  ---  Ҫ��ʾ���ַ�
			row_col    ---  ��ʾ����
output:		none
describe:	����Ļ����ʾһ���ַ�		
notice:
creat date: 2008-7-25
creator:	dengyihong
************************************************************/
/*
void lcd_printf_char(Uchar disp_char, Uchar row_col)
{
    lcd_write_reg(row_col & ROW_COL);
    lcd_wait();
    lcd_write_data(disp_char);
    lcd_wait();	
}
*/

/***********************************************************
name:		lcd_write_reg		
input:		command  ---  Ҫд�������
output:		none
describe:	д�������LCD	
notice:
creat date: 2008-7-25
creator:	dengyihong
************************************************************/
void lcd_write_reg(Uchar command)
{
    LCD_DATA = command;		// д��������
    LCD_RS = 0;
    LCD_RW = 0;
    LCD_EN = 1;
    delay_2us(100);
    LCD_EN = 0;
}


/***********************************************************
name:		lcd_write_data		
input:		value  ---  Ҫд�������
output:		none
describe:	д���ݵ�LCD	
notice:
creat date: 2008-7-25
creator:	dengyihong
************************************************************/
void lcd_write_data(Uchar value)
{
   LCD_DATA =  value;		//д����
   LCD_RS = 1;
   LCD_RW = 0;
   LCD_EN = 1;
   delay_2us(100);
   LCD_EN = 0; 	
}

/***********************************************************
name:		lcd_wait	
input:		none
output:		none
describe:	�ȴ�LCD�ڲ��������	
notice:
creat date: 2008-7-25
creator:	dengyihong
************************************************************/
void lcd_wait(void)
{
    Uchar value = 0;
       
    do
    {
        LCD_RS = 0;
        LCD_RW = 1;
        LCD_EN = 1;
        value = LCD_DATA;	
        LCD_EN = 0;
    }while(value & 0x80);		// �ȴ��ڲ��������	
}

